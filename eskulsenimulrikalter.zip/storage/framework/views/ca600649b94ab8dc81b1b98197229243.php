<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prestasi | Seni Multikalter</title>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
        rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/prestasi.css')); ?>">
</head>

<body>
    
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main class="prestasi-page">
        <div class="prestasi-container">

            
            <section class="prestasi-header">
                <h1>
                    PRESTASI
                    <span>
                        SENI MULTIKALTER
                    </span>
                </h1>

                <p>
                    Berbagai pencapaian dan prestasi yang diraih
                    oleh anggota Seni Multikalter.
                </p>
            </section>

            
            <section class="prestasi-search">
                <form action="<?php echo e(route('user.prestasi')); ?>" method="GET" class="search-form">
                    <div class="search-input-wrapper">
                        <span class="search-icon">
                            ⌕
                        </span>

                        <input
                            type="text"
                            name="search"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Cari prestasi..."
                            autocomplete="off"
                        >
                    </div>

                    <button type="submit" class="search-button">
                        Cari
                    </button>

                    <?php if(request('search')): ?>
                        <a href="<?php echo e(route('user.prestasi')); ?>" class="reset-button">
                            Reset
                        </a>
                    <?php endif; ?>
                </form>
            </section>

            
            <?php if(request('search')): ?>
                <div class="search-result-info">
                    Hasil pencarian untuk:
                    <strong>
                        "<?php echo e(request('search')); ?>"
                    </strong>
                </div>
            <?php endif; ?>

            
            <section class="prestasi-grid">
                <?php $__empty_1 = true; $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article
                        class="prestasi-card"
                        data-title="<?php echo e($item->nama_prestasi); ?>"
                        data-description="<?php echo e(strip_tags($item->deskripsi ?? 'Tidak ada deskripsi prestasi.')); ?>"
                        data-date="<?php echo e($item->created_at ? $item->created_at->format('Y') : '-'); ?>"
                        data-image="<?php echo e($item->foto ? asset('images/prestasi/' . $item->foto) : asset('img/DokumSM(4).jpg')); ?>"
                    >
                        
                        <div class="prestasi-image">
                            <?php if($item->foto): ?>
                                <img
                                    src="<?php echo e(asset('images/prestasi/' . $item->foto)); ?>"
                                    alt="<?php echo e($item->nama_prestasi); ?>"
                                    loading="lazy"
                                    onerror="
                                        this.onerror=null;
                                        this.src='<?php echo e(asset('img/DokumSM(4).jpg')); ?>';
                                    "
                                >
                            <?php else: ?>
                                <img
                                    src="<?php echo e(asset('img/DokumSM(4).jpg')); ?>"
                                    alt="<?php echo e($item->nama_prestasi); ?>"
                                >
                            <?php endif; ?>
                        </div>

                        
                        <div class="prestasi-content">
                            <span class="prestasi-label">
                                PRESTASI
                            </span>

                            <h2>
                                <?php echo e($item->nama_prestasi); ?>

                            </h2>

                            <p>
                                <?php echo e(\Illuminate\Support\Str::limit(strip_tags($item->deskripsi ?? ''), 120)); ?>

                            </p>

                            <div class="prestasi-card-footer">
                                <span class="prestasi-date">
                                    <?php echo e($item->created_at ? $item->created_at->format('Y') : '-'); ?>

                                </span>

                                <button type="button" class="detail-button">
                                    Lihat Detail →
                                </button>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                    <article class="prestasi-empty">
                        <div class="empty-icon">
                            🏆
                        </div>

                        <h2>
                            Belum Ada Prestasi
                        </h2>

                        <?php if(request('search')): ?>
                            <p>
                                Prestasi dengan kata

                                <strong>
                                    "<?php echo e(request('search')); ?>"
                                </strong>

                                tidak ditemukan.
                            </p>

                            <a href="<?php echo e(route('user.prestasi')); ?>" class="empty-button">
                                Tampilkan Semua Prestasi
                            </a>
                        <?php else: ?>
                            <p>
                                Belum ada data prestasi
                                yang ditambahkan.
                            </p>
                        <?php endif; ?>
                    </article>
                <?php endif; ?>
            </section>

            
            <?php if(
                $prestasi instanceof \Illuminate\Pagination\LengthAwarePaginator &&
                $prestasi->lastPage() > 1
            ): ?>
                <div class="prestasi-pagination">
                    <ul class="pagination-list">

                        
                        <?php if($prestasi->onFirstPage()): ?>
                            <li>
                                <span class="pagination-link disabled">
                                    ‹
                                </span>
                            </li>
                        <?php else: ?>
                            <li>
                                <a
                                    href="<?php echo e($prestasi->appends(request()->query())->previousPageUrl()); ?>"
                                    class="pagination-link"
                                    aria-label="Halaman sebelumnya"
                                >
                                    ‹
                                </a>
                            </li>
                        <?php endif; ?>

                        
                        <?php
                            $currentPage = $prestasi->currentPage();
                            $lastPage = $prestasi->lastPage();
                            $startPage = max(1, $currentPage - 2);
                            $endPage = min($lastPage, $currentPage + 2);
                        ?>

                        
                        <?php if($startPage > 1): ?>
                            <li>
                                <a href="<?php echo e($prestasi->appends(request()->query())->url(1)); ?>" class="pagination-link">
                                    1
                                </a>
                            </li>

                            <?php if($startPage > 2): ?>
                                <li>
                                    <span class="pagination-dots">
                                        ...
                                    </span>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>

                        
                        <?php for($page = $startPage; $page <= $endPage; $page++): ?>
                            <?php if($page == $currentPage): ?>
                                <li>
                                    <span class="pagination-link active">
                                        <?php echo e($page); ?>

                                    </span>
                                </li>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e($prestasi->appends(request()->query())->url($page)); ?>" class="pagination-link">
                                        <?php echo e($page); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endfor; ?>

                        
                        <?php if($endPage < $lastPage): ?>
                            <?php if($endPage < $lastPage - 1): ?>
                                <li>
                                    <span class="pagination-dots">
                                        ...
                                    </span>
                                </li>
                            <?php endif; ?>

                            <li>
                                <a href="<?php echo e($prestasi->appends(request()->query())->url($lastPage)); ?>" class="pagination-link">
                                    <?php echo e($lastPage); ?>

                                </a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if($prestasi->hasMorePages()): ?>
                            <li>
                                <a
                                    href="<?php echo e($prestasi->appends(request()->query())->nextPageUrl()); ?>"
                                    class="pagination-link"
                                    aria-label="Halaman berikutnya"
                                >
                                    ›
                                </a>
                            </li>
                        <?php else: ?>
                            <li>
                                <span class="pagination-link disabled">
                                    ›
                                </span>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>

            
            <section class="prestasi-closing">
                <div class="closing-line"></div>

                <h2>
                    Terus Berkarya,
                    <span>
                        Terus Berprestasi.
                    </span>
                </h2>

                <p>
                    Setiap pencapaian merupakan hasil dari proses,
                    kerja keras, kreativitas, dan kebersamaan
                    seluruh anggota Seni Multikalter.
                </p>
            </section>

        </div>
    </main>

    
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="prestasi-modal" id="prestasiModal" aria-hidden="true">
        <div class="modal-box" role="dialog" aria-modal="true">
            <button type="button" class="modal-close" id="modalClose">
                ×
            </button>

            <div class="modal-image-wrapper">
                <img src="<?php echo e(asset('img/DokumSM(4).jpg')); ?>" alt="Prestasi" id="modalImage">
            </div>

            <div class="modal-content">
                <span>
                    PRESTASI
                </span>

                <h2 id="modalTitle">
                    Prestasi Seni Multikalter
                </h2>

                <p id="modalDescription">
                    Deskripsi prestasi.
                </p>

                <div class="modal-divider"></div>

                <small id="modalDate">
                    Tahun -
                </small>
            </div>
        </div>
    </div>

    
    <script src="<?php echo e(asset('js/user/prestasi.js')); ?>"></script>
</body>

</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/user/prestasi.blade.php ENDPATH**/ ?>