<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berita | Seni Multikalter</title>
    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
        rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/berita.css')); ?>">
</head>

<body>
    
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main class="berita-page">
        <div class="berita-container">
            
            <section class="berita-header reveal">
                <h1>
                    BERITA
                    <span>SENI MULTIKALTER</span>
                </h1>

                <div class="header-image">
                    <img src="<?php echo e(asset('img/DokumSM(4).jpg')); ?>" alt="Kegiatan Seni Multikalter">
                </div>
                <p class="header-caption">
                    Kabar terbaru seputar kegiatan dan
                    prestasi Seni Multikalter
                </p>

                <p class="header-description">
                    Dapatkan informasi terkini mengenai
                    kegiatan, prestasi dan berbagai hal
                    menarik dari Ekstrakurikuler kami.
                </p>
            </section>
            

            <?php $__empty_1 = true; $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <section class="featured-news reveal">

                            <article class="featured-card" data-title="<?php echo e($item->judul_berita); ?>"
                                data-description="<?php echo e(strip_tags($item->deskripsi_berita)); ?>"
                                data-date="<?php echo e(\Carbon\Carbon::parse($item->tanggal_upload)->format('d F Y')); ?>" data-image="<?php echo e($item->foto
                    ? asset('images/berita/' . $item->foto)
                    : asset('img/DokumSM(4).jpg')); ?>">

                                
                                <div class="featured-image">

                                    <?php if($item->foto): ?>

                                        <img src="<?php echo e(asset('images/berita/' . $item->foto)); ?>" alt="<?php echo e($item->judul_berita); ?>">

                                    <?php else: ?>

                                        <img src="<?php echo e(asset('img/DokumSM(4).jpg')); ?>" alt="<?php echo e($item->judul_berita); ?>">

                                    <?php endif; ?>

                                </div>


                                
                                <div class="featured-content">

                                    <h2>
                                        <?php echo e($item->judul_berita); ?>

                                    </h2>

                                    <p>
                                        <?php echo e(\Illuminate\Support\Str::limit(
                    strip_tags($item->deskripsi_berita),
                    180
                )); ?>

                                    </p>

                                </div>

                            </article>


                            
                            <div class="upload-date">

                                <span>
                                    upload:
                                </span>

                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_upload)->format('d F Y')); ?>


                            </div>

                        </section>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                

                <section class="featured-news reveal">

                    <article class="featured-card">

                        <div class="featured-content">

                            <h2>
                                Belum ada berita
                            </h2>

                            <p>
                                Belum ada berita yang dipublikasikan oleh
                                Seni Multikalter.
                            </p>

                        </div>

                    </article>

                </section>

            <?php endif; ?>

    </main>
    <!-- JS -->
    <script src="<?php echo e(asset('js/user/berita.js')); ?>"></script>
    
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/user/berita.blade.php ENDPATH**/ ?>