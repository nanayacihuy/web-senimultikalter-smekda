<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Agenda | Seni Multikalter</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/agenda.css')); ?>">
</head>
<body x-data="{ sidebarOpen: true }">
    <?php echo $__env->make('components.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="agenda-layout">
    <?php echo $__env->make('components.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <main class="agenda-main">
            <h2>Kelola agenda</h2>
            <?php if(session('success')): ?>
                <div class="alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert-error">
                    <strong>Terjadi kesalahan:</strong>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> <?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="top-section">
                
                <div class="controls">
                    
                    <form
                        action="<?php echo e(route('admin.agenda')); ?>"
                        method="GET"
                        class="search-form">
                        <input
                            type="text"
                            name="search"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Cari agenda......"
                            class="search-input">
                    </form>
                    <div class="control-row">
                        
                        <button
                            type="button"
                            class="btn-add"
                            onclick="openAddModal()">+ Tambah agenda</button>
                        
                        <input
                            type="date"
                            class="date-filter"
                            id="dateFilter">
                    </div>
                </div>
                <div class="stats">
                    
                    <div class="stat-card">
                        <span class="stat-title">Total Agenda</span>
                        <span class="stat-number"><?php echo e($agenda->count()); ?></span>
                    </div>
                    
                    <div class="stat-card">
                        <span class="stat-title">Agenda terpublis</span>
                        <span class="stat-number"><?php echo e($agenda->count()); ?></span>
                    </div>
                    
                    <div class="stat-card">
                        <span class="stat-title">Draft</span>
                        <span class="stat-number">0</span>
                    </div>
                    
                    <div class="stat-card">
                        <span class="stat-title">Sampah</span>
                        <span class="stat-number">0</span>
                    </div>
                </div>
            </div>
            
            <div class="table-container">
                <div class="table-wrapper">
                    <table class="agenda-table" id="agendaTable">
                        <thead>
                            <tr>
                                <th style="width: 70px;">No</th>
                                <th>Nama Kegiatan</th>
                                <th>Waktu</th>
                                <th>Tempat</th>
                                <th>Materi/kegiatan</th>
                                <th style="width: 150px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    
                                    <td class="number-cell">
                                        <?php echo e($agenda->firstItem() + $index); ?>.
                                    </td>
                                    
                                    <td class="activity-name">
                                        <?php echo e($item->nama_kegiatan); ?>

                                    </td>
                                    
                                    <td class="text-cell">
                                        <?php echo e($item->waktu); ?>

                                    </td>
                                    
                                    <td class="text-cell"><?php echo e($item->tempat); ?></td>
                                    
                                    <td class="text-cell"><?php echo e($item->materi); ?></td>
                                    
                                    <td>
                                        <div class="action-wrapper">
                                            
                                            <button
                                                type="button"
                                                class="btn-edit"
                                                onclick="openEditModal(
                                                    <?php echo e($item->id_agenda); ?>,
                                                    <?php echo \Illuminate\Support\Js::from($item->nama_kegiatan)->toHtml() ?>,
                                                    <?php echo \Illuminate\Support\Js::from($item->waktu)->toHtml() ?>,
                                                    <?php echo \Illuminate\Support\Js::from($item->tempat)->toHtml() ?>,
                                                    <?php echo \Illuminate\Support\Js::from($item->materi)->toHtml() ?>
                                                )">Ubah</button>
                                            
                                            <form
                                                action="<?php echo e(route('admin.agenda.destroy', $item->id_agenda)); ?>"
                                                method="POST"
                                                onsubmit="return confirm('Yakin ingin menghapus agenda ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button
                                                    type="submit"
                                                    class="btn-delete">Hapus</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6"class="empty-row">Tidak ada agenda yang ditemukan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-4"><?php echo e($agenda->links()); ?></div>
            </div>
        </main>
    </div>
    
    <div class="modal-overlay"id="agendaModal">
        <div class="modal-box">
            <h3 class="modal-title" id="modalTitle">Tambah Agenda</h3>
            <form
                id="agendaForm"
                action="<?php echo e(route('admin.agenda.store')); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <input
                    type="hidden"
                    name="_method"
                    id="formMethod"
                    value="POST"
                >
                
                <div class="form-group">
                    <label class="form-label">Nama Kegiatan</label>
                    <input
                        type="text"
                        name="nama_kegiatan"
                        id="namaKegiatan"
                        class="form-input"
                        placeholder="Contoh: Latihan Tari Tradisi"
                        required>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Waktu</label>
                        <textarea
                            name="waktu"
                            id="waktu"
                            rows="3"
                            class="form-textarea"
                            placeholder="Rabu&#10;15.00 - 16.30"
                            required></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tempat</label>
                        <textarea
                            name="tempat"
                            id="tempat"
                            rows="3"
                            class="form-textarea"
                            placeholder="Panggung&#10;SMKN 2 Purwakarta"
                            required></textarea>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Materi / Kegiatan</label>
                    <textarea
                        name="materi"
                        id="materi"
                        rows="3"
                        class="form-textarea"
                        placeholder="Latihan gerak dasar (olah tubuh)"
                        required
                    ></textarea>
                </div>
                
                <div class="modal-buttons">
                    <button
                        type="button"
                        class="btn-cancel"
                        onclick="closeModal()">Batal</button>
                    <button type="submit"class="btn-save">Simpan</button>
                </div>
            </form>
        </div>
    </div>
    
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="<?php echo e(asset('js/admin/agenda.js')); ?>"></script>
</body>
</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/admin/agenda.blade.php ENDPATH**/ ?>