<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Galeri - Seni Multikalter</title>

    
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        [x-cloak] {
            display: none !important;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            min-height: 100%;
        }

        body {
            overflow-x: hidden;
        }
    </style>
</head>

<body class="bg-[#4A0000] font-sans antialiased">

    
    <?php echo $__env->make('components.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <div class="flex pt-20 min-h-screen">

        
        <?php echo $__env->make('components.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        
        <main
            class="flex-1 min-w-0
                   bg-white rounded-tl-3xl
                   p-6 md:p-8
                   min-h-[calc(100vh-5rem)]
                   overflow-x-hidden
                   md:ml-64">

            
            <div
                class="flex flex-col sm:flex-row
                       justify-between
                       items-start sm:items-center
                       gap-4 mb-8">

                
                <h2 class="text-3xl font-bold text-[#4A0000]">
                    Kelola Galeri
                </h2>


                
                <div
                    class="flex items-center
                           gap-3
                           w-full sm:w-auto">

                    
                    <button
                        type="button"
                        onclick="openAddModal()"
                        class="h-[42px]
                               flex items-center justify-center
                               border-2 border-[#4A0000]
                               text-[#4A0000]
                               hover:bg-[#4A0000]
                               hover:text-white
                               px-5
                               rounded-2xl
                               text-xs font-bold
                               transition
                               shadow-sm
                               whitespace-nowrap">

                        + Tambah galeri

                    </button>


                    
                    <form
                        method="GET"
                        action="<?php echo e(route('admin.galeri')); ?>"
                        class="h-[42px]">

                        <input
                            type="date"
                            name="tanggal"
                            value="<?php echo e(request('tanggal')); ?>"
                            onchange="this.form.submit()"
                            class="h-[42px]
                                   border-2 border-[#4A0000]
                                   text-[#4A0000]
                                   px-4
                                   rounded-2xl
                                   text-xs font-bold
                                   focus:outline-none
                                   bg-white
                                   cursor-pointer">

                    </form>

                </div>
            </div>


            
            <?php if(session('success')): ?>

                <div
                    class="mb-6 p-4
                           rounded-xl
                           bg-green-100
                           border border-green-300
                           text-green-700
                           text-sm font-semibold">

                    <?php echo e(session('success')); ?>


                </div>

            <?php endif; ?>


            
            <?php if($errors->any()): ?>

                <div
                    class="mb-6 p-4
                           rounded-xl
                           bg-red-100
                           border border-red-300
                           text-red-700
                           text-sm">

                    <ul class="list-disc pl-5">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <?php echo e($error); ?>

                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>

                </div>

            <?php endif; ?>


            
            <div
                class="border-2 border-[#9E6B6B]
                       rounded-3xl
                       overflow-hidden
                       shadow-sm">

                <div class="overflow-x-auto">

                    
                    <form
                        method="GET"
                        action="<?php echo e(route('admin.galeri')); ?>"
                        class="flex flex-col sm:flex-row gap-3 mb-5"
                    >
                        <input
                            type="text"
                            name="search"
                            value="<?php echo e(request('search')); ?>"
                            placeholder="Cari judul atau kategori..."
                            class="flex-1 px-4 py-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#4A0000] text-sm"
                        >

                        <button
                            type="submit"
                            class="bg-[#4A0000] text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-[#660000] transition text-sm"
                        >
                            Cari
                        </button>

                        <?php if(request('search')): ?>
                            <a
                                href="<?php echo e(route('admin.galeri')); ?>"
                                class="text-center px-6 py-2.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-100 transition"
                            >
                                Reset
                            </a>
                        <?php endif; ?>
                    </form>

                    <table
                        class="w-full
                               text-center
                               border-collapse">

                        
                        <thead>

                            <tr
                                class="bg-[#9E6B6B]
                                       text-white
                                       text-lg md:text-xl
                                       font-bold">

                                <th class="py-3.5 px-4 w-16">
                                    No
                                </th>

                                <th class="py-3.5 px-4 w-44">
                                    Gambar
                                </th>

                                <th class="py-3.5 px-6">
                                    Judul
                                </th>

                                <th class="py-3.5 px-6">
                                    Kategori
                                </th>

                                <th class="py-3.5 px-6">
                                    Tanggal Upload
                                </th>

                                <th class="py-3.5 px-6 w-44">
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        
                        <tbody
                            class="divide-y
                                   divide-emerald-600/30
                                   text-[#4A0000]
                                   font-bold
                                   text-base md:text-lg">

                            <?php $__empty_1 = true; $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr
                                    class="hover:bg-amber-50/50
                                           transition">

                                    
                                    <td
                                        class="py-5 px-4
                                               text-2xl
                                               font-black">

                                        <?php echo e($galeri->firstItem() + $index); ?>.

                                    </td>


                                    
                                    <td class="py-5 px-4">

                                        <div
                                            class="w-36 h-20
                                                   bg-[#4A0000]
                                                   rounded-2xl
                                                   mx-auto
                                                   shadow-md
                                                   overflow-hidden
                                                   flex items-center
                                                   justify-center">

                                            <?php if($item->foto): ?>

                                                <img
                                                    src="<?php echo e(asset('storage/' . $item->foto)); ?>"
                                                    alt="<?php echo e($item->judul_galeri); ?>"
                                                    class="w-full h-full object-cover"
                                                    onerror="this.style.display='none';">

                                            <?php else: ?>

                                                <span
                                                    class="text-white text-xs">

                                                    Tidak ada foto

                                                </span>

                                            <?php endif; ?>

                                        </div>

                                    </td>


                                    
                                    <td
                                        class="py-5 px-6
                                               font-extrabold
                                               text-xl
                                               leading-tight
                                               max-w-xs">

                                        <?php echo e($item->judul_galeri); ?>


                                    </td>


                                    
                                    <td class="py-5 px-6">

                                        <span
                                            class="inline-block
                                                   bg-[#F3E7D7]
                                                   text-[#4A0000]
                                                   px-3 py-1
                                                   rounded-full
                                                   text-sm
                                                   font-bold
                                                   whitespace-nowrap">

                                            <?php echo e($item->kategori); ?>


                                        </span>

                                    </td>


                                    
                                    <td
                                        class="py-5 px-6
                                               text-base md:text-lg">

                                        <?php if($item->tanggal_upload): ?>

                                            <?php echo e(\Carbon\Carbon::parse($item->tanggal_upload)->translatedFormat('d F Y')); ?>


                                        <?php else: ?>

                                            -

                                        <?php endif; ?>

                                    </td>


                                    
                                    <td class="py-5 px-6">

                                        <div
                                            class="flex justify-center
                                                   items-center gap-2">

                                            
                                            <button
                                                type="button"
                                                onclick="openEditModal(
                                                    '<?php echo e($item->id_galeri); ?>',
                                                    <?php echo \Illuminate\Support\Js::from($item->judul_galeri)->toHtml() ?>,
                                                    <?php echo \Illuminate\Support\Js::from($item->kategori)->toHtml() ?>,
                                                    '<?php echo e($item->tanggal_upload); ?>'
                                                )"
                                                class="bg-[#D4A017]
                                                       hover:bg-yellow-600
                                                       text-white
                                                       text-xs
                                                       px-4 py-1.5
                                                       rounded-lg
                                                       transition
                                                       font-medium
                                                       shadow-sm">

                                                Edit

                                            </button>


                                            
                                            <form
                                                action="<?php echo e(route('admin.galeri.destroy', $item->id_galeri)); ?>"
                                                method="POST"
                                                onsubmit="return confirm('Yakin ingin menghapus foto galeri ini?')">

                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button
                                                    type="submit"
                                                    class="bg-[#E53935]
                                                           hover:bg-red-700
                                                           text-white
                                                           text-xs
                                                           px-4 py-1.5
                                                           rounded-lg
                                                           transition
                                                           font-medium
                                                           shadow-sm">

                                                    Hapus

                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <tr>

                                    <td
                                        colspan="6"
                                        class="py-10
                                               text-gray-400
                                               font-normal
                                               text-sm">

                                        Belum ada data galeri.

                                    </td>

                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                    <div class="mt-4">
                        <?php echo e($galeri->links()); ?>

                    </div>

                </div>

            </div>

        </main>

    </div>


    
    <div
        id="addModal"
        class="fixed inset-0
               bg-black/60
               z-50
               hidden
               items-center
               justify-center
               p-4">

        <div
            class="bg-white
                   rounded-2xl
                   max-w-lg
                   w-full
                   p-6
                   shadow-2xl
                   space-y-4
                   border-2 border-[#9E6B6B]">

            <h3
                class="text-xl font-bold
                       text-[#4A0000]">

                Tambah Foto Galeri

            </h3>


            <form
                action="<?php echo e(route('admin.galeri.store')); ?>"
                method="POST"
                enctype="multipart/form-data"
                class="space-y-4">

                <?php echo csrf_field(); ?>


                
                <div>

                    <label
                        for="judul_galeri"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Judul Gambar / Kegiatan

                    </label>

                    <input
                        type="text"
                        name="judul_galeri"
                        id="judul_galeri"
                        value="<?php echo e(old('judul_galeri')); ?>"
                        required
                        placeholder="Contoh: Penampilan Tari Tradisi"
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                
                <div>

                    <label
                        for="kategori"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Kategori

                    </label>

                    <select
                        name="kategori"
                        id="kategori"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                        <option value="">
                            -- Pilih Kategori --
                        </option>

                        <option value="Tari Tradisi"
                            <?php echo e(old('kategori') == 'Tari Tradisi' ? 'selected' : ''); ?>>
                            Tari Tradisi
                        </option>

                        <option value="Modern Dance"
                            <?php echo e(old('kategori') == 'Modern Dance' ? 'selected' : ''); ?>>
                            Modern Dance
                        </option>

                        <option value="Vokal"
                            <?php echo e(old('kategori') == 'Vokal' ? 'selected' : ''); ?>>
                            Vokal
                        </option>

                        <option value="Kabaret"
                            <?php echo e(old('kategori') == 'Kabaret' ? 'selected' : ''); ?>>
                            Kabaret
                        </option>

                        <option value="Angklung & Musik"
                            <?php echo e(old('kategori') == 'Angklung & Musik' ? 'selected' : ''); ?>>
                            Angklung & Musik
                        </option>

                        <option value="Foto Bersama"
                            <?php echo e(old('kategori') == 'Foto Bersama' ? 'selected' : ''); ?>>
                            Foto Bersama
                        </option>

                    </select>

                </div>


                
                <div>

                    <label
                        for="tanggal_upload"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Tanggal Upload

                    </label>

                    <input
                        type="date"
                        name="tanggal_upload"
                        id="tanggal_upload"
                        value="<?php echo e(old('tanggal_upload', date('Y-m-d'))); ?>"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                
                <div>

                    <label
                        for="foto"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Upload Foto

                    </label>

                    <input
                        type="file"
                        name="foto"
                        id="foto"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white">

                    <p
                        class="text-[11px]
                               text-gray-500
                               mt-1">

                        Format: JPG, JPEG, PNG, WEBP.
                        Maksimal 5 MB.

                    </p>

                </div>


                
                <div
                    class="flex justify-end
                           gap-2
                           pt-3">

                    <button
                        type="button"
                        onclick="closeAddModal()"
                        class="px-4 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-gray-200
                               text-gray-700
                               hover:bg-gray-300
                               transition">

                        Batal

                    </button>

                    <button
                        type="submit"
                        class="px-5 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-[#4A0000]
                               text-white
                               hover:bg-[#660000]
                               transition">

                        Simpan

                    </button>

                </div>

            </form>

        </div>

    </div>


    
    <div
        id="editModal"
        class="fixed inset-0
               bg-black/60
               z-50
               hidden
               items-center
               justify-center
               p-4">

        <div
            class="bg-white
                   rounded-2xl
                   max-w-lg
                   w-full
                   p-6
                   shadow-2xl
                   space-y-4
                   border-2 border-[#9E6B6B]">

            <h3
                class="text-xl font-bold
                       text-[#4A0000]">

                Edit Foto Galeri

            </h3>


            <form
                id="editForm"
                method="POST"
                enctype="multipart/form-data"
                class="space-y-4">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>


                
                <div>

                    <label
                        for="edit_judul_galeri"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Judul Gambar / Kegiatan

                    </label>

                    <input
                        type="text"
                        name="judul_galeri"
                        id="edit_judul_galeri"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                
                <div>

                    <label
                        for="edit_kategori"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Kategori

                    </label>

                    <select
                        name="kategori"
                        id="edit_kategori"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                        <option value="">
                            -- Pilih Kategori --
                        </option>

                        <option value="Tari Tradisi">
                            Tari Tradisi
                        </option>

                        <option value="Modern Dance">
                            Modern Dance
                        </option>

                        <option value="Vokal">
                            Vokal
                        </option>

                        <option value="Kabaret">
                            Kabaret
                        </option>

                        <option value="Angklung & Musik">
                            Angklung & Musik
                        </option>

                        <option value="Foto Bersama">
                            Foto Bersama
                        </option>

                    </select>

                </div>


                
                <div>

                    <label
                        for="edit_tanggal_upload"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Tanggal Upload

                    </label>

                    <input
                        type="date"
                        name="tanggal_upload"
                        id="edit_tanggal_upload"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                
                <div>

                    <label
                        for="edit_foto"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Ganti Foto

                    </label>

                    <input
                        type="file"
                        name="foto"
                        id="edit_foto"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white">

                    <p
                        class="text-[11px]
                               text-gray-500
                               mt-1">

                        Kosongkan jika tidak ingin mengganti foto.

                    </p>

                </div>


                
                <div
                    class="flex justify-end
                           gap-2
                           pt-3">

                    <button
                        type="button"
                        onclick="closeEditModal()"
                        class="px-4 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-gray-200
                               text-gray-700
                               hover:bg-gray-300
                               transition">

                        Batal

                    </button>

                    <button
                        type="submit"
                        class="px-5 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-[#4A0000]
                               text-white
                               hover:bg-[#660000]
                               transition">

                        Simpan Perubahan

                    </button>

                </div>

            </form>

        </div>

    </div>


    
    <script>

        /* =====================================================
           SIDEBAR
        ====================================================== */

        const menuToggle =
            document.getElementById('menuToggle');

        const sidebar =
            document.getElementById('sidebar');

        const sidebarOverlay =
            document.getElementById('sidebarOverlay');


        if (menuToggle && sidebar && sidebarOverlay) {

            menuToggle.addEventListener('click', function () {

                sidebar.classList.toggle('-translate-x-full');

                sidebarOverlay.classList.toggle('hidden');

            });


            sidebarOverlay.addEventListener('click', function () {

                sidebar.classList.add('-translate-x-full');

                sidebarOverlay.classList.add('hidden');

            });

        }


        /* =====================================================
           MODAL TAMBAH GALERI
        ====================================================== */

        const addModal =
            document.getElementById('addModal');


        function openAddModal() {

            addModal.classList.remove('hidden');

            addModal.classList.add('flex');

        }


        function closeAddModal() {

            addModal.classList.add('hidden');

            addModal.classList.remove('flex');

        }


        /* =====================================================
           MODAL EDIT GALERI
        ====================================================== */

        const editModal =
            document.getElementById('editModal');

        const editForm =
            document.getElementById('editForm');

        const editJudul =
            document.getElementById('edit_judul_galeri');

        const editKategori =
            document.getElementById('edit_kategori');

        const editTanggal =
            document.getElementById('edit_tanggal_upload');


        function openEditModal(
            id,
            judul,
            kategori,
            tanggal
        ) {

            // Masukkan data lama
            editJudul.value = judul;

            editKategori.value = kategori;

            editTanggal.value = tanggal;


            // URL update
            editForm.action =
                "<?php echo e(url('/admin/galeri')); ?>/" + id;


            // Tampilkan modal
            editModal.classList.remove('hidden');

            editModal.classList.add('flex');

        }


        function closeEditModal() {

            editModal.classList.add('hidden');

            editModal.classList.remove('flex');

        }


        /* =====================================================
           KLIK LUAR MODAL TAMBAH
        ====================================================== */

        addModal.addEventListener('click', function (event) {

            if (event.target === addModal) {

                closeAddModal();

            }

        });


        /* =====================================================
           KLIK LUAR MODAL EDIT
        ====================================================== */

        editModal.addEventListener('click', function (event) {

            if (event.target === editModal) {

                closeEditModal();

            }

        });


        /* =====================================================
           TOMBOL ESC
        ====================================================== */

        document.addEventListener('keydown', function (event) {

            if (event.key === 'Escape') {

                closeAddModal();

                closeEditModal();

            }

        });

    </script>

</body>
</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/admin/galeri.blade.php ENDPATH**/ ?>