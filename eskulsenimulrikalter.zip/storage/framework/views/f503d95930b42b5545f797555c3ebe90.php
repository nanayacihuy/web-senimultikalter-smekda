<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Data Anggota | Seni Multikalter</title>

    
    <script src="https://cdn.tailwindcss.com"></script>

    
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js">
    </script>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/anggotaa.css')); ?>">
</head>

<body x-data="{ sidebarOpen: false }">

    
    <?php echo $__env->make('components.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('components.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <main class="admin-content anggota-page">

        <div class="content-inner">

            
            <div class="page-header">

                <h2 class="page-title">
                    Kelola data anggota
                </h2>

                <button type="button" class="btn-add" id="btnTambah">
                    + Tambah anggota
                </button>

            </div>


            
            <?php if(session('success')): ?>

                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>

            <?php endif; ?>


            
            <?php if($errors->any()): ?>

                <div class="alert alert-error">

                    <strong>
                        Data belum berhasil disimpan.
                    </strong>

                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>

            <?php endif; ?>


            
            <div class="table-wrapper">

                <table class="anggota-table">

                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Kelas</th>
                            <th>Bidang</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>


                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                
                                <td>
                                    <?php echo e($index + 1); ?>.
                                </td>


                                
                                <td>
                                    <?php echo e($item->nama_anggota); ?>

                                </td>


                                
                                <td>
                                    <?php echo e($item->kelas_anggota); ?>

                                </td>


                                
                                <td>
                                    <?php echo e($item->bidang_anggota); ?>

                                </td>


                                
                                <td>

                                    <div class="action-buttons">

                                        
                                        <button type="button" class="btn-edit" onclick="bukaModalEdit(
                                                        <?php echo e($item->id_anggota); ?>,
                                                        <?php echo \Illuminate\Support\Js::from($item->nama_anggota)->toHtml() ?>,
                                                        <?php echo \Illuminate\Support\Js::from($item->kelas_anggota)->toHtml() ?>,
                                                        <?php echo \Illuminate\Support\Js::from($item->bidang_anggota)->toHtml() ?>
                                                    )">
                                            Ubah
                                        </button>


                                        
                                        <form action="<?php echo e(route('admin.anggota.destroy', $item->id_anggota)); ?>" method="POST"
                                            onsubmit="return confirm('Yakin ingin menghapus anggota ini?')">

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="submit" class="btn-delete">
                                                Hapus
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td colspan="5" class="empty-data">
                                    Belum ada data anggota.
                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </main>


    
    <div class="modal-overlay" id="modalOverlay">

        <div class="modal-box" id="modalBox">

            <h3 class="modal-title" id="modalTitle">
                Tambah Data Anggota
            </h3>


            
            <form action="<?php echo e(route('admin.anggota.store')); ?>" method="POST" id="anggotaForm">

                <?php echo csrf_field(); ?>

                
                <input type="hidden" name="_method" id="methodInput" value="POST">


                
                <div class="form-group">

                    <label for="nama_anggota">
                        Nama Lengkap
                    </label>

                    <input type="text" id="nama_anggota" name="nama_anggota" placeholder="Masukkan nama anggota"
                        value="<?php echo e(old('nama_anggota')); ?>" required>

                </div>


                
                <div class="form-group">

                    <label for="kelas_anggota">
                        Kelas
                    </label>

                    <input type="text" id="kelas_anggota" name="kelas_anggota" placeholder="Contoh: XII RPL 1"
                        value="<?php echo e(old('kelas_anggota')); ?>" required>

                </div>


                
                <div class="form-group">

                    <label for="bidang_anggota">
                        Bidang Seni
                    </label>

                    <input type="text" id="bidang_anggota" name="bidang_anggota" placeholder="Contoh: Tari Tradisi"
                        value="<?php echo e(old('bidang_anggota')); ?>" required>

                </div>


                
                <div class="modal-actions">

                    <button type="button" class="btn-cancel" id="btnBatal">
                        Batal
                    </button>

                    <button type="submit" class="btn-save">
                        Simpan
                    </button>

                </div>

            </form>

        </div>

    </div>


    
    <script>

        // =========================
        // ELEMENT
        // =========================

        const modalOverlay = document.getElementById('modalOverlay');

        const modalTitle = document.getElementById('modalTitle');

        const anggotaForm = document.getElementById('anggotaForm');

        const methodInput = document.getElementById('methodInput');

        const namaInput = document.getElementById('nama_anggota');

        const kelasInput = document.getElementById('kelas_anggota');

        const bidangInput = document.getElementById('bidang_anggota');

        const btnTambah = document.getElementById('btnTambah');

        const btnBatal = document.getElementById('btnBatal');


        // =========================
        // TAMBAH ANGGOTA
        // =========================

        btnTambah.addEventListener('click', function () {

            modalTitle.textContent = 'Tambah Data Anggota';

            anggotaForm.action =
                "<?php echo e(route('admin.anggota.store')); ?>";

            methodInput.value = 'POST';

            namaInput.value = '';
            kelasInput.value = '';
            bidangInput.value = '';

            modalOverlay.classList.add('show');

            namaInput.focus();

        });


        // =========================
        // UBAH ANGGOTA
        // =========================

        function bukaModalEdit(id, nama, kelas, bidang) {

            modalTitle.textContent = 'Ubah Data Anggota';

            anggotaForm.action =
                "<?php echo e(url('/admin/anggota')); ?>/" + id;

            methodInput.value = 'PUT';

            namaInput.value = nama;

            kelasInput.value = kelas;

            bidangInput.value = bidang;

            modalOverlay.classList.add('show');

            namaInput.focus();
        }


        // =========================
        // TUTUP MODAL
        // =========================

        function tutupModal() {

            modalOverlay.classList.remove('show');

        }


        // =========================
        // TOMBOL BATAL
        // =========================

        btnBatal.addEventListener('click', function () {

            tutupModal();

        });


        // =========================
        // KLIK DI LUAR MODAL
        // =========================

        modalOverlay.addEventListener('click', function (event) {

            if (event.target === modalOverlay) {

                tutupModal();

            }

        });


        // =========================
        // TOMBOL ESC
        // =========================

        document.addEventListener('keydown', function (event) {

            if (event.key === 'Escape') {

                tutupModal();

            }

        });

    </script>

</body>

</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/admin/anggota.blade.php ENDPATH**/ ?>