<!DOCTYPE html>
<html lang="id" class="h-full bg-slate-100">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin | Seni Multikalter</title>
    
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="h-full text-slate-800 antialiased bg-slate-100">

    
    <?php if (isset($component)) { $__componentOriginalf818c67b6eb448edb731318e48f2e69b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf818c67b6eb448edb731318e48f2e69b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf818c67b6eb448edb731318e48f2e69b)): ?>
<?php $attributes = $__attributesOriginalf818c67b6eb448edb731318e48f2e69b; ?>
<?php unset($__attributesOriginalf818c67b6eb448edb731318e48f2e69b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf818c67b6eb448edb731318e48f2e69b)): ?>
<?php $component = $__componentOriginalf818c67b6eb448edb731318e48f2e69b; ?>
<?php unset($__componentOriginalf818c67b6eb448edb731318e48f2e69b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalbebe114f3ccde4b38d7462a3136be045 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbebe114f3ccde4b38d7462a3136be045 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $attributes = $__attributesOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__attributesOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbebe114f3ccde4b38d7462a3136be045)): ?>
<?php $component = $__componentOriginalbebe114f3ccde4b38d7462a3136be045; ?>
<?php unset($__componentOriginalbebe114f3ccde4b38d7462a3136be045); ?>
<?php endif; ?>

    
    <main class="lg:pl-64 pt-24 pb-12 min-h-screen flex flex-col bg-slate-100">
        <div class="px-4 sm:px-6 lg:px-8 max-w-7xl w-full mx-auto space-y-8 flex-1">
            
            
            <div class="flex items-center justify-between border-b border-slate-200 pb-5">
                <div>
                    <h1 class="text-2xl font-bold text-slate-900 tracking-tight">Dashboard</h1>
                    <p class="text-xs sm:text-sm text-slate-500 mt-1">Ringkasan data & aktivitas Seni Multikalter.</p>
                </div>
                <span class="text-xs font-medium text-slate-600 bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-sm">
                    <?php echo e(\Carbon\Carbon::now()->translatedFormat('d M Y')); ?>

                </span>
            </div>

            
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                    <div class="p-2.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-100"><i data-lucide="users" class="w-5 h-5"></i></div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Anggota</p>
                        <p class="text-xl font-bold text-slate-900 mt-0.5"><?php echo e($totalAnggota); ?></p>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                    <div class="p-2.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-100"><i data-lucide="newspaper" class="w-5 h-5"></i></div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Berita</p>
                        <p class="text-xl font-bold text-slate-900 mt-0.5"><?php echo e($totalBerita); ?></p>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                    <div class="p-2.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-100"><i data-lucide="trophy" class="w-5 h-5"></i></div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Prestasi</p>
                        <p class="text-xl font-bold text-slate-900 mt-0.5"><?php echo e($totalPrestasi); ?></p>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                    <div class="p-2.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-100"><i data-lucide="calendar" class="w-5 h-5"></i></div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Agenda</p>
                        <p class="text-xl font-bold text-slate-900 mt-0.5"><?php echo e($totalAgenda); ?></p>
                    </div>
                </div>

                <div class="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3 col-span-2 sm:col-span-1">
                    <div class="p-2.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-100"><i data-lucide="image" class="w-5 h-5"></i></div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Galeri</p>
                        <p class="text-xl font-bold text-slate-900 mt-0.5"><?php echo e($totalGaleri); ?></p>
                    </div>
                </div>
            </div>

            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                
                <div class="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h2 class="font-bold text-slate-900 flex items-center gap-2 text-sm">
                            <i data-lucide="newspaper" class="w-4 h-4 text-rose-900"></i> Berita Terbaru
                        </h2>
                        <a href="<?php echo e(route('admin.berita')); ?>" class="text-xs font-semibold text-rose-900 hover:text-rose-700 transition-colors">Lihat Semua</a>
                    </div>

                    <?php if($berita->count() > 0): ?>
                        <div class="divide-y divide-slate-100">
                            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="py-3.5 first:pt-0 last:pb-0">
                                    <div class="flex items-center gap-2 text-xs text-slate-400 mb-1">
                                        <i data-lucide="clock" class="w-3 h-3 text-slate-400"></i>
                                        <?php echo e($item->tanggal_upload ? \Carbon\Carbon::parse($item->tanggal_upload)->translatedFormat('d M Y') : '-'); ?>

                                    </div>
                                    <h3 class="font-semibold text-slate-800 text-sm hover:text-rose-900 transition-colors">
                                        <?php echo e($item->judul_berita); ?>

                                    </h3>
                                    <?php if($item->deskripsi_berita): ?>
                                        <p class="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                                            <?php echo e(strip_tags($item->deskripsi_berita)); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-xs text-slate-400 text-center py-6">Belum ada berita.</p>
                    <?php endif; ?>
                </div>

                
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h2 class="font-bold text-slate-900 flex items-center gap-2 text-sm">
                            <i data-lucide="calendar" class="w-4 h-4 text-rose-900"></i> Agenda
                        </h2>
                        <a href="<?php echo e(route('admin.agenda')); ?>" class="text-xs font-semibold text-rose-900 hover:text-rose-700 transition-colors">Lihat Semua</a>
                    </div>

                    <?php if($agenda->count() > 0): ?>
                        <div class="space-y-3">
                            <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-3.5 rounded-lg bg-slate-50 border border-slate-100">
                                    <h3 class="font-semibold text-slate-800 text-sm"><?php echo e($item->nama_kegiatan); ?></h3>
                                    <div class="mt-2 space-y-1.5 text-xs text-slate-500">
                                        <p class="flex items-center gap-2">
                                            <i data-lucide="clock" class="w-3.5 h-3.5 text-slate-400"></i> <?php echo e($item->waktu ?? '-'); ?>

                                        </p>
                                        <p class="flex items-center gap-2">
                                            <i data-lucide="map-pin" class="w-3.5 h-3.5 text-slate-400"></i> <?php echo e($item->tempat ?? '-'); ?>

                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-xs text-slate-400 text-center py-6">Belum ada agenda.</p>
                    <?php endif; ?>
                </div>

            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h2 class="font-bold text-slate-900 flex items-center gap-2 text-sm">
                            <i data-lucide="trophy" class="w-4 h-4 text-rose-900"></i> Prestasi Terbaru
                        </h2>
                        <a href="<?php echo e(route('admin.prestasi')); ?>" class="text-xs font-semibold text-rose-900 hover:text-rose-700 transition-colors">Lihat Semua</a>
                    </div>

                    <?php if($prestasi->count() > 0): ?>
                        <ul class="divide-y divide-slate-100 text-sm">
                            <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="py-3 flex items-center justify-between gap-2">
                                    <span class="font-medium text-slate-700 truncate">
                                        <?php echo e($item->nama_prestasi ?? $item->judul_prestasi ?? 'Prestasi'); ?>

                                    </span>
                                    <?php if($item->tahun): ?>
                                        <span class="text-xs bg-rose-50 text-rose-900 font-medium px-2.5 py-0.5 rounded border border-rose-200/60 shrink-0">
                                            <?php echo e($item->tahun); ?>

                                        </span>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-xs text-slate-400 text-center py-6">Belum ada prestasi.</p>
                    <?php endif; ?>
                </div>

                
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h2 class="font-bold text-slate-900 flex items-center gap-2 text-sm">
                            <i data-lucide="image" class="w-4 h-4 text-rose-900"></i> Dokumentasi Galeri
                        </h2>
                        <a href="<?php echo e(route('admin.galeri')); ?>" class="text-xs font-semibold text-rose-900 hover:text-rose-700 transition-colors">Lihat Semua</a>
                    </div>

                    <?php if($galeri->count() > 0): ?>
                        <div class="flex flex-wrap gap-2">
                            <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->judul_galeri): ?>
                                    <span class="inline-flex items-center gap-1.5 text-xs bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-200">
                                        <i data-lucide="tag" class="w-3 h-3 text-slate-400"></i>
                                        <?php echo e($item->judul_galeri); ?>

                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-xs text-slate-400 text-center py-6">Belum ada galeri.</p>
                    <?php endif; ?>
                </div>

            </div>

        </div>

        
        <footer class="border-t border-slate-200 bg-white mt-12 py-4 px-6 text-center text-xs text-slate-400">
            © <?php echo e(date('Y')); ?> Seni Multikalter SMKN 2 Purwakarta.
        </footer>
    </main>

    <script>
        lucide.createIcons();
    </script>
</body>
</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>