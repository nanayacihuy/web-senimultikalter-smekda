<link rel="stylesheet"href="<?php echo e(asset('css/navbar.css')); ?>">
<nav class="navbar" id="navbar">
    <!-- ================= LOGO ================= -->
    <div class="navbar-logo">
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('img/logoseni26.jpeg')); ?>"alt="Logo Seni Multikalter">
        </a>
    </div>
    <!-- ================= MENU ================= -->
    <div class="navbar-menu" id="navbarMenu">
        <a href="<?php echo e(route('user.beranda')); ?>" class="<?php echo e(request()->routeIs('user.beranda') ? 'active' : ''); ?>">Beranda</a>
        <a href="<?php echo e(route('user.profile')); ?>" class="<?php echo e(request()->routeIs('user.profile') ? 'active' : ''); ?>">Profile</a>
        <a href="<?php echo e(route('user.organigram')); ?>" class="<?php echo e(request()->routeIs('user.organigram') ? 'active' : ''); ?>">Organigram</a>
        <a href="<?php echo e(route('user.galeri')); ?>" class="<?php echo e(request()->routeIs('user.galeri') ? 'active' : ''); ?>">Galeri</a>
        <a href="<?php echo e(route('user.berita')); ?>"class="<?php echo e(request()->routeIs('user.berita') ? 'active' : ''); ?>">Berita</a>
        <a href="<?php echo e(route('user.prestasi')); ?>"class="<?php echo e(request()->routeIs('user.prestasi') ? 'active' : ''); ?>">Prestasi</a>
        <a href="<?php echo e(route('user.agenda')); ?>"class="<?php echo e(request()->routeIs('user.agenda') ? 'active' : ''); ?>">Agenda</a>
        <a href="<?php echo e(route('user.anggota')); ?>" class="<?php echo e(request()->routeIs('user.anggota') ? 'active' : ''); ?>">Anggota</a>
        <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.*') ? 'active' : ''); ?>">Admin Panel</a>
            <?php endif; ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline-block; margin: 0;">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background: transparent; border: none; color: inherit; font: inherit; font-size: inherit; font-weight: inherit; cursor: pointer; padding: 6px 2px;"title="Keluar akun">Logout</button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('user.login')); ?>"class="<?php echo e(request()->routeIs('user.login') ? 'active' : ''); ?>">Login</a>
        <?php endif; ?>
</div>
    <!-- ================= HAMBURGER ================= -->
    <button class="navbar-toggle"id="navbarToggle"type="button"aria-label="Buka menu">
        <span></span>
        <span></span>
        <span></span>
    </button>
</nav>
<script src="<?php echo e(asset('js/user/navbar.js')); ?>" defer></script><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/components/navbar.blade.php ENDPATH**/ ?>