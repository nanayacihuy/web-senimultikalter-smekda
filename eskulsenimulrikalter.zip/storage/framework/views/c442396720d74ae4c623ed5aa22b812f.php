<!DOCTYPE html>
<html lang="id"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organigram | Seni Multikalter</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/organigram.css')); ?>">
</head>
<body>
    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="organigram">
        <section class="header-organigram">
            <h1>STRUKTUR KEPENGURUSAN</h1>
            <h2>SENI MULTIKALTER</h2>
            <p>Periode 2025/2026</p>
            <!-- FOTO HEADER -->
            <img src="<?php echo e(asset('img/SERTIJAB2526.jpeg')); ?>" alt="Kegiatan Seni Multikalter"class="foto-organigram">
            <p class="deskripsi-header">
                Memperkenalkan jajaran pengurus yang siap menginspirasi,
                berkarya, dan menghidupkan kreasi bersama.
            </p>
        </section>
       <!-- =====================================================
     PEMBINA
====================================================== -->
<section class="bagian">
    <h3 class="judul-bagian">Pembina</h3>
    <div class="card-pembina">
        <?php
            $pembina = $organigram->filter(function ($item) {
                return strtolower(trim($item->jabatan)) === 'pembina';
            });
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $pembina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($item->foto): ?>
                
                <img src="<?php echo e(asset('images/organigram/' . $item->foto)); ?>" alt="<?php echo e($item->nama_pengurus); ?>"
                    onerror="this.src='<?php echo e(asset('img/DokumSM(4).jpg')); ?>'">
            <?php else: ?>
                <img src="<?php echo e(asset('img/DokumSM(4).jpg')); ?>" alt="<?php echo e($item->nama_pengurus); ?>">
            <?php endif; ?>
            <h4><?php echo e($item->nama_pengurus); ?></h4>
            <p>Pembina Seni Multikalter</p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="foto-kosong">-</div>
            <h4>Belum ada data pembina</h4>
            <p>-</p>
        <?php endif; ?>
    </div>
</section>
        <!-- =====================================================
             PELATIH
        ====================================================== -->
        <section class="bagian">
            <h3 class="judul-bagian">Pelatih Bidang</h3>
            <div class="pelatih-container">
                <?php
                    $pelatih = $organigram->filter(function ($item) {
                        return strtolower(trim($item->jabatan)) === 'pelatih';
                    });
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $pelatih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card-pelatih">
                        <?php if($item->foto): ?>
                            <img src="<?php echo e(asset('images/organigram/' . $item->foto)); ?>" alt="<?php echo e($item->nama_pengurus); ?>"
                                onerror="this.src='<?php echo e(asset('img/DokumSM(4).jpg')); ?>'">
                        <?php else: ?>
                            <div class="foto-kosong">-</div>
                        <?php endif; ?>
                        <h4><?php echo e($item->bidang_pengurus ?: 'Pelatih'); ?></h4>
                        <p> <?php echo e($item->nama_pengurus); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <!-- VOKAL -->
                    <div class="card-pelatih">
                        <div class="foto-kosong">-</div>
                        <h4>Vokal</h4>
                        <p>Belum ada data</p>
                    </div>
                    <!-- TARI TRADISI -->
                    <div class="card-pelatih">
                        <div class="foto-kosong">-</div>
                        <h4>Tari Tradisi</h4>
                        <p>Belum ada data</p>
                    </div>
                    <!-- ANGKLUNG & MUSIK -->
                    <div class="card-pelatih">
                        <div class="foto-kosong">-</div>
                        <h4>Angklung & Musik</h4>
                        <p>Belum ada data</p>
                    </div>
                    <!-- KABARET -->
                    <div class="card-pelatih">
                        <div class="foto-kosong">-</div>
                        <h4>Kabaret</h4>
                        <p>Belum ada data</p>
                    </div>
                    <!-- MODERN DANCE -->
                    <div class="card-pelatih">
                        <div class="foto-kosong">-</div>
                        <h4>Modern Dance</h4>
                        <p>Belum ada data</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>
        <!-- =====================================================
             INTI SENI & BIDANG
        ====================================================== -->
        <section class="bagian">
            <h3 class="judul-bagian">Inti Seni dan Bidang</h3>
            <div class="bidang-container">
                <?php
                    $daftarBidang = [
                        'Inti Umum Seni',
                        'Vokal',
                        'Tari Tradisi',
                        'Modern Dance',
                        'Kabaret',
                        'Angklung & Musik'
                    ];
                ?>
                <?php $__currentLoopData = $daftarBidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- =================================================
                         CARD BIDANG
                    ================================================== -->
                    <div class="card-bidang">
                        <h4>
                            <?php if($bidang === 'Inti Umum Seni'): ?>
                                Inti Umum Seni
                            <?php else: ?>
                                Bidang <?php echo e($bidang); ?>

                            <?php endif; ?>
                        </h4>
                        <div class="isi-bidang">
                            <?php
                                /*
                                |--------------------------------------------------------------------------
                                | MENCARI DATA BERDASARKAN BIDANG
                                |--------------------------------------------------------------------------
                                */
                                $anggotaBidang = $organigram->filter(function ($item) use ($bidang) {
                                    return strtolower(trim($item->bidang_pengurus))
                                        === strtolower(trim($bidang));

                                });
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $anggotaBidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p>
                                    <?php if(strtolower(trim($anggota->jabatan)) === 'ketua'): ?>
                                        <b>Mentri (Ketua):<?php echo e($anggota->nama_pengurus); ?> </b>
                                    <?php elseif(strtolower(trim($anggota->jabatan)) === 'wakil ketua'): ?>
                                        Wamentri (Wakil Ketua):<?php echo e($anggota->nama_pengurus); ?>

                                    <?php else: ?>
                                        <?php echo e($anggota->jabatan); ?>:
                                        <?php echo e($anggota->nama_pengurus); ?>

                                    <?php endif; ?>
                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Belum ada data pengurus.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </main>
    <!-- =====================================================
         FOOTER
    ====================================================== -->
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/user/organigram.blade.php ENDPATH**/ ?>