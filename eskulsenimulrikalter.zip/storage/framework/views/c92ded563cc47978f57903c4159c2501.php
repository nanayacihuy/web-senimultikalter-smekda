<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun | Seni Multikalter</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/daftar.css')); ?>">
</head>

<body>


    
    <main class="daftar-page">

        
        <section class="daftar-left">
            <div class="left-content">
                <div class="logo-container">
                    <img id="logoPreview" src="<?php echo e(asset('img/logoseni26.jpeg')); ?>" alt="Logo Seni Multikalter">
                </div>

                <h1>Seni Multikalter</h1>
                <p class="tagline">“Wadahnya Para Seniman”</p>
                <p class="left-description">
                    Silakan lengkapi data diri kalian untuk membuat akun dan menjadi bagian dari Seni Multikalter.
                </p>
            </div>
        </section>

        
        <section class="daftar-right">
            <div class="daftar-card">

                <div class="card-header">
                    <h3>Daftar Akun</h3>
                    <p class="daftar-subtitle">Buat akun untuk melanjutkan</p>
                </div>

                
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                
                <form id="registerForm" method="POST" action="<?php echo e(route('register.process')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <div class="form-group">
                        <label for="nama">Nama Lengkap</label>
                        <input type="text" id="nama" name="nama" value="<?php echo e(old('nama')); ?>"
                            placeholder="Masukkan nama lengkap" required>
                    </div>

                    
                    <div class="form-group">
                        <label for="regUsername">Username</label>
                        <input type="text" id="regUsername" name="username" placeholder="Buat username" required>
                    </div>

                    
                    <div class="form-group">
                        <label for="regPassword">Password</label>
                        <div class="password-box">
                            <input type="password" id="regPassword" name="password" placeholder="Buat password" required>
                            <button type="button" class="show-password" data-target="regPassword" aria-label="Tampilkan Password">👁</button>
                        </div>
                    </div>

                    
                    <div class="form-group">
                        <label for="confirmPassword">Konfirmasi Password</label>
                        <div class="password-box">
                            <input type="password" id="confirmPassword" name="password_confirmation" placeholder="Ulangi password" required>
                            <button type="button" class="show-password" data-target="confirmPassword" aria-label="Tampilkan Konfirmasi Password">👁</button>
                        </div>
                    </div>

                    
                    <button type="submit" class="daftar-button">Daftar Sekarang</button>
                </form>

                
                <p id="registerMessage" class="register-message"></p>

                
                <p class="register-text">
                    Sudah punya akun?
                    <a href="<?php echo e(route('user.login')); ?>" class="<?php echo e(request()->routeIs('user.login') ? 'active' : ''); ?>">
                        Login di sini
                    </a>
                </p>

            </div>
        </section>

    </main>
    
    <script src="<?php echo e(asset('js/user/daftar.js')); ?>"></script>

</body>

</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/user/daftar.blade.php ENDPATH**/ ?>