<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Seni Multikalter</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>

<body>

    <main class="login-page">

        <!-- ================= BAGIAN KIRI ================= -->
        <section class="login-left">
            <div class="left-content">
                <div class="logo-container">
                    <img id="logoPreview" src="<?php echo e(asset('img/logoseni26.jpeg')); ?>" alt="Logo Seni Multikalter">
                </div>
                
                <h1>Seni Multikalter</h1>
                <p class="tagline">“Wadahnya Para Seniman”</p>
                <p class="left-description">
                    Sebelum mulai berproses bersama kami, silakan daftarkan diri Anda di website resmi kami.
                </p>
            </div>
        </section>

        <!-- ================= BAGIAN KANAN ================= -->
        <section class="login-right">
            <div class="login-card">

                <div class="card-header">
                    <h3>Selamat Datang</h3>
                    <p class="login-subtitle">Masuk untuk melanjutkan ke akun Anda</p>
                </div>

                <!-- PESAN ERROR / SUCCESS -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <!-- FORM -->
                <form id="loginForm" action="<?php echo e(route('login.process')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- USERNAME -->
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>"
                            placeholder="Masukkan username Anda" required>
                    </div>

                    <!-- PASSWORD -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="password-box">
                            <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                            <button type="button" id="showPassword" aria-label="Tampilkan Password">👁</button>
                        </div>
                    </div>

                    <!-- ROLE -->
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required>
                            <option value="">-- Pilih Role --</option>
                            <option value="user" <?php echo e(old('role') === 'user' ? 'selected' : ''); ?>>User</option>
                            <option value="admin" <?php echo e(old('role') === 'admin' ? 'selected' : ''); ?>>Admin</option>
                        </select>
                    </div>

                    <!-- BUTTON -->
                    <button type="submit" class="login-button">Masuk</button>
                </form>

                <!-- DAFTAR -->
                <p class="register-text">
                    Belum punya akun?
                    <a href="<?php echo e(route('user.daftar')); ?>" class="<?php echo e(request()->routeIs('user.daftar') ? 'active' : ''); ?>">
                        Daftar sekarang
                    </a>
                </p>

                <!-- PESAN JAVASCRIPT -->
                <p id="loginMessage" class="login-message"></p>

            </div>
        </section>

    </main>

    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('js/user/login.js')); ?>"></script>

</body>

</html><?php /**PATH C:\laragon\www\WEBESKULSENI\resources\views/user/login.blade.php ENDPATH**/ ?>