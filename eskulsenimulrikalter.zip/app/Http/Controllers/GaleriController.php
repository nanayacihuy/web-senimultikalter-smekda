<?php

namespace App\Http\Controllers;

use App\Models\Galeri;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GaleriController extends Controller
{
    // ================================
    // HALAMAN ADMIN GALERI
    // ================================
    public function index(Request $request)
    {
        $query = Galeri::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('judul_galeri', 'like', "%{$search}%")
                  ->orWhere('kategori', 'like', "%{$search}%");
            });
        }

        $galeri = $query
            ->orderBy('tanggal_upload', 'desc')
            ->paginate(12)
            ->withQueryString();

        return view('admin.galeri', compact('galeri'));
    }

    // ================================
    // HALAMAN USER GALERI
    // ================================
    public function userIndex(Request $request)
    {
        $query = Galeri::query();

        // Catatan: halaman galeri user dikelompokkan per kategori
        // (lihat resources/views/user/galeri.blade.php), jadi di sini
        // kita hanya menerapkan pencarian, TANPA pagination -
        // supaya tiap kategori tetap tampil utuh dalam satu halaman.
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('judul_galeri', 'like', "%{$search}%")
                  ->orWhere('kategori', 'like', "%{$search}%");
            });
        }

        $galeri = $query->orderBy('tanggal_upload', 'desc')->get();

        return view('user.galeri', compact('galeri'));
    }

    // ================================
    // TAMBAH DATA GALERI
    // ================================
    public function store(Request $request)
    {
        $request->validate([
            'judul_galeri' => 'required|max:255',
            'foto' => 'required|image|mimes:jpg,jpeg,png,webp|max:2048',
            'tanggal_upload' => 'required|date',
            'kategori' => 'required|max:100',
        ]);

        // Simpan foto ke storage/app/public/galeri
        $foto = $request->file('foto')->store('galeri', 'public');

        Galeri::create([
            'judul_galeri' => $request->judul_galeri,
            'foto' => $foto,
            'tanggal_upload' => $request->tanggal_upload,
            'kategori' => $request->kategori,
        ]);

        return redirect()
            ->route('admin.galeri')
            ->with('success', 'Data galeri berhasil ditambahkan.');
    }

    // ================================
    // EDIT DATA GALERI
    // ================================
    public function update(Request $request, $id)
    {
        $galeri = Galeri::findOrFail($id);

        $request->validate([
            'judul_galeri' => 'required|max:255',
            'foto' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'tanggal_upload' => 'required|date',
            'kategori' => 'required|max:100',
        ]);

        $data = [
            'judul_galeri' => $request->judul_galeri,
            'tanggal_upload' => $request->tanggal_upload,
            'kategori' => $request->kategori,
        ];

        // Kalau admin mengganti foto
        if ($request->hasFile('foto')) {

            // Hapus foto lama
            if (
                $galeri->foto &&
                Storage::disk('public')->exists($galeri->foto)
            ) {
                Storage::disk('public')->delete($galeri->foto);
            }

            // Simpan foto baru
            $data['foto'] = $request->file('foto')->store(
                'galeri',
                'public'
            );
        }

        $galeri->update($data);

        return redirect()
            ->route('admin.galeri')
            ->with('success', 'Data galeri berhasil diperbarui.');
    }

    // ================================
    // HAPUS DATA GALERI
    // ================================
    public function destroy($id)
    {
        $galeri = Galeri::findOrFail($id);

        // Hapus file foto dari storage
        if (
            $galeri->foto &&
            Storage::disk('public')->exists($galeri->foto)
        ) {
            Storage::disk('public')->delete($galeri->foto);
        }

        // Hapus data dari database
        $galeri->delete();

        return redirect()
            ->route('admin.galeri')
            ->with('success', 'Data galeri berhasil dihapus.');
    }
}