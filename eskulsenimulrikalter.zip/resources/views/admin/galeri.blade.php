<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Galeri - Seni Multikalter</title>

    {{-- Tailwind --}}
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        [x-cloak] {
            display: none !important;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            min-height: 100%;
        }

        body {
            overflow-x: hidden;
        }
    </style>
</head>

<body class="bg-[#4A0000] font-sans antialiased">

    {{-- =========================================================
         NAVBAR ADMIN
    ========================================================== --}}
    @include('components.admin.navbar')


    {{-- =========================================================
         LAYOUT
    ========================================================== --}}
    <div class="flex pt-20 min-h-screen">

        {{-- =====================================================
             SIDEBAR ADMIN
        ====================================================== --}}
        @include('components.admin.sidebar')


        {{-- =====================================================
             MAIN CONTENT
        ====================================================== --}}
        <main
            class="flex-1 min-w-0
                   bg-white rounded-tl-3xl
                   p-6 md:p-8
                   min-h-[calc(100vh-5rem)]
                   overflow-x-hidden
                   md:ml-64">

            {{-- =================================================
                 HEADER JUDUL + AKSI
            ================================================== --}}
            <div
                class="flex flex-col sm:flex-row
                       justify-between
                       items-start sm:items-center
                       gap-4 mb-8">

                {{-- Judul --}}
                <h2 class="text-3xl font-bold text-[#4A0000]">
                    Kelola Galeri
                </h2>


                {{-- Tombol + Kalender --}}
                <div
                    class="flex items-center
                           gap-3
                           w-full sm:w-auto">

                    {{-- TOMBOL TAMBAH --}}
                    <button
                        type="button"
                        onclick="openAddModal()"
                        class="h-[42px]
                               flex items-center justify-center
                               border-2 border-[#4A0000]
                               text-[#4A0000]
                               hover:bg-[#4A0000]
                               hover:text-white
                               px-5
                               rounded-2xl
                               text-xs font-bold
                               transition
                               shadow-sm
                               whitespace-nowrap">

                        + Tambah galeri

                    </button>


                    {{-- FILTER TANGGAL --}}
                    <form
                        method="GET"
                        action="{{ route('admin.galeri') }}"
                        class="h-[42px]">

                        <input
                            type="date"
                            name="tanggal"
                            value="{{ request('tanggal') }}"
                            onchange="this.form.submit()"
                            class="h-[42px]
                                   border-2 border-[#4A0000]
                                   text-[#4A0000]
                                   px-4
                                   rounded-2xl
                                   text-xs font-bold
                                   focus:outline-none
                                   bg-white
                                   cursor-pointer">

                    </form>

                </div>
            </div>


            {{-- =================================================
                 SUCCESS MESSAGE
            ================================================== --}}
            @if(session('success'))

                <div
                    class="mb-6 p-4
                           rounded-xl
                           bg-green-100
                           border border-green-300
                           text-green-700
                           text-sm font-semibold">

                    {{ session('success') }}

                </div>

            @endif


            {{-- =================================================
                 VALIDATION ERROR
            ================================================== --}}
            @if($errors->any())

                <div
                    class="mb-6 p-4
                           rounded-xl
                           bg-red-100
                           border border-red-300
                           text-red-700
                           text-sm">

                    <ul class="list-disc pl-5">

                        @foreach($errors->all() as $error)

                            <li>
                                {{ $error }}
                            </li>

                        @endforeach

                    </ul>

                </div>

            @endif


            {{-- =================================================
                 TABLE
            ================================================== --}}
            <div
                class="border-2 border-[#9E6B6B]
                       rounded-3xl
                       overflow-hidden
                       shadow-sm">

                <div class="overflow-x-auto">

                    {{-- SEARCH BAR --}}
                    <form
                        method="GET"
                        action="{{ route('admin.galeri') }}"
                        class="flex flex-col sm:flex-row gap-3 mb-5"
                    >
                        <input
                            type="text"
                            name="search"
                            value="{{ request('search') }}"
                            placeholder="Cari judul atau kategori..."
                            class="flex-1 px-4 py-2.5 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#4A0000] text-sm"
                        >

                        <button
                            type="submit"
                            class="bg-[#4A0000] text-white font-semibold px-6 py-2.5 rounded-lg hover:bg-[#660000] transition text-sm"
                        >
                            Cari
                        </button>

                        @if(request('search'))
                            <a
                                href="{{ route('admin.galeri') }}"
                                class="text-center px-6 py-2.5 rounded-lg border border-gray-300 text-sm text-gray-600 hover:bg-gray-100 transition"
                            >
                                Reset
                            </a>
                        @endif
                    </form>

                    <table
                        class="w-full
                               text-center
                               border-collapse">

                        {{-- TABLE HEADER --}}
                        <thead>

                            <tr
                                class="bg-[#9E6B6B]
                                       text-white
                                       text-lg md:text-xl
                                       font-bold">

                                <th class="py-3.5 px-4 w-16">
                                    No
                                </th>

                                <th class="py-3.5 px-4 w-44">
                                    Gambar
                                </th>

                                <th class="py-3.5 px-6">
                                    Judul
                                </th>

                                <th class="py-3.5 px-6">
                                    Kategori
                                </th>

                                <th class="py-3.5 px-6">
                                    Tanggal Upload
                                </th>

                                <th class="py-3.5 px-6 w-44">
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        {{-- TABLE BODY --}}
                        <tbody
                            class="divide-y
                                   divide-emerald-600/30
                                   text-[#4A0000]
                                   font-bold
                                   text-base md:text-lg">

                            @forelse($galeri as $index => $item)

                                <tr
                                    class="hover:bg-amber-50/50
                                           transition">

                                    {{-- NO --}}
                                    <td
                                        class="py-5 px-4
                                               text-2xl
                                               font-black">

                                        {{ $galeri->firstItem() + $index }}.

                                    </td>


                                    {{-- FOTO --}}
                                    <td class="py-5 px-4">

                                        <div
                                            class="w-36 h-20
                                                   bg-[#4A0000]
                                                   rounded-2xl
                                                   mx-auto
                                                   shadow-md
                                                   overflow-hidden
                                                   flex items-center
                                                   justify-center">

                                            @if($item->foto)

                                                <img
                                                    src="{{ asset('storage/' . $item->foto) }}"
                                                    alt="{{ $item->judul_galeri }}"
                                                    class="w-full h-full object-cover"
                                                    onerror="this.style.display='none';">

                                            @else

                                                <span
                                                    class="text-white text-xs">

                                                    Tidak ada foto

                                                </span>

                                            @endif

                                        </div>

                                    </td>


                                    {{-- JUDUL --}}
                                    <td
                                        class="py-5 px-6
                                               font-extrabold
                                               text-xl
                                               leading-tight
                                               max-w-xs">

                                        {{ $item->judul_galeri }}

                                    </td>


                                    {{-- KATEGORI --}}
                                    <td class="py-5 px-6">

                                        <span
                                            class="inline-block
                                                   bg-[#F3E7D7]
                                                   text-[#4A0000]
                                                   px-3 py-1
                                                   rounded-full
                                                   text-sm
                                                   font-bold
                                                   whitespace-nowrap">

                                            {{ $item->kategori }}

                                        </span>

                                    </td>


                                    {{-- TANGGAL --}}
                                    <td
                                        class="py-5 px-6
                                               text-base md:text-lg">

                                        @if($item->tanggal_upload)

                                            {{ \Carbon\Carbon::parse($item->tanggal_upload)->translatedFormat('d F Y') }}

                                        @else

                                            -

                                        @endif

                                    </td>


                                    {{-- AKSI --}}
                                    <td class="py-5 px-6">

                                        <div
                                            class="flex justify-center
                                                   items-center gap-2">

                                            {{-- EDIT --}}
                                            <button
                                                type="button"
                                                onclick="openEditModal(
                                                    '{{ $item->id_galeri }}',
                                                    @js($item->judul_galeri),
                                                    @js($item->kategori),
                                                    '{{ $item->tanggal_upload }}'
                                                )"
                                                class="bg-[#D4A017]
                                                       hover:bg-yellow-600
                                                       text-white
                                                       text-xs
                                                       px-4 py-1.5
                                                       rounded-lg
                                                       transition
                                                       font-medium
                                                       shadow-sm">

                                                Edit

                                            </button>


                                            {{-- HAPUS --}}
                                            <form
                                                action="{{ route('admin.galeri.destroy', $item->id_galeri) }}"
                                                method="POST"
                                                onsubmit="return confirm('Yakin ingin menghapus foto galeri ini?')">

                                                @csrf
                                                @method('DELETE')

                                                <button
                                                    type="submit"
                                                    class="bg-[#E53935]
                                                           hover:bg-red-700
                                                           text-white
                                                           text-xs
                                                           px-4 py-1.5
                                                           rounded-lg
                                                           transition
                                                           font-medium
                                                           shadow-sm">

                                                    Hapus

                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            @empty

                                <tr>

                                    <td
                                        colspan="6"
                                        class="py-10
                                               text-gray-400
                                               font-normal
                                               text-sm">

                                        Belum ada data galeri.

                                    </td>

                                </tr>

                            @endforelse

                        </tbody>

                    </table>

                    <div class="mt-4">
                        {{ $galeri->links() }}
                    </div>

                </div>

            </div>

        </main>

    </div>


    {{-- =========================================================
         MODAL TAMBAH GALERI
    ========================================================== --}}
    <div
        id="addModal"
        class="fixed inset-0
               bg-black/60
               z-50
               hidden
               items-center
               justify-center
               p-4">

        <div
            class="bg-white
                   rounded-2xl
                   max-w-lg
                   w-full
                   p-6
                   shadow-2xl
                   space-y-4
                   border-2 border-[#9E6B6B]">

            <h3
                class="text-xl font-bold
                       text-[#4A0000]">

                Tambah Foto Galeri

            </h3>


            <form
                action="{{ route('admin.galeri.store') }}"
                method="POST"
                enctype="multipart/form-data"
                class="space-y-4">

                @csrf


                {{-- JUDUL --}}
                <div>

                    <label
                        for="judul_galeri"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Judul Gambar / Kegiatan

                    </label>

                    <input
                        type="text"
                        name="judul_galeri"
                        id="judul_galeri"
                        value="{{ old('judul_galeri') }}"
                        required
                        placeholder="Contoh: Penampilan Tari Tradisi"
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                {{-- KATEGORI --}}
                <div>

                    <label
                        for="kategori"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Kategori

                    </label>

                    <select
                        name="kategori"
                        id="kategori"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                        <option value="">
                            -- Pilih Kategori --
                        </option>

                        <option value="Tari Tradisi"
                            {{ old('kategori') == 'Tari Tradisi' ? 'selected' : '' }}>
                            Tari Tradisi
                        </option>

                        <option value="Modern Dance"
                            {{ old('kategori') == 'Modern Dance' ? 'selected' : '' }}>
                            Modern Dance
                        </option>

                        <option value="Vokal"
                            {{ old('kategori') == 'Vokal' ? 'selected' : '' }}>
                            Vokal
                        </option>

                        <option value="Kabaret"
                            {{ old('kategori') == 'Kabaret' ? 'selected' : '' }}>
                            Kabaret
                        </option>

                        <option value="Angklung & Musik"
                            {{ old('kategori') == 'Angklung & Musik' ? 'selected' : '' }}>
                            Angklung & Musik
                        </option>

                        <option value="Foto Bersama"
                            {{ old('kategori') == 'Foto Bersama' ? 'selected' : '' }}>
                            Foto Bersama
                        </option>

                    </select>

                </div>


                {{-- TANGGAL --}}
                <div>

                    <label
                        for="tanggal_upload"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Tanggal Upload

                    </label>

                    <input
                        type="date"
                        name="tanggal_upload"
                        id="tanggal_upload"
                        value="{{ old('tanggal_upload', date('Y-m-d')) }}"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                {{-- FOTO --}}
                <div>

                    <label
                        for="foto"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Upload Foto

                    </label>

                    <input
                        type="file"
                        name="foto"
                        id="foto"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white">

                    <p
                        class="text-[11px]
                               text-gray-500
                               mt-1">

                        Format: JPG, JPEG, PNG, WEBP.
                        Maksimal 5 MB.

                    </p>

                </div>


                {{-- BUTTON --}}
                <div
                    class="flex justify-end
                           gap-2
                           pt-3">

                    <button
                        type="button"
                        onclick="closeAddModal()"
                        class="px-4 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-gray-200
                               text-gray-700
                               hover:bg-gray-300
                               transition">

                        Batal

                    </button>

                    <button
                        type="submit"
                        class="px-5 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-[#4A0000]
                               text-white
                               hover:bg-[#660000]
                               transition">

                        Simpan

                    </button>

                </div>

            </form>

        </div>

    </div>


    {{-- =========================================================
         MODAL EDIT GALERI
    ========================================================== --}}
    <div
        id="editModal"
        class="fixed inset-0
               bg-black/60
               z-50
               hidden
               items-center
               justify-center
               p-4">

        <div
            class="bg-white
                   rounded-2xl
                   max-w-lg
                   w-full
                   p-6
                   shadow-2xl
                   space-y-4
                   border-2 border-[#9E6B6B]">

            <h3
                class="text-xl font-bold
                       text-[#4A0000]">

                Edit Foto Galeri

            </h3>


            <form
                id="editForm"
                method="POST"
                enctype="multipart/form-data"
                class="space-y-4">

                @csrf
                @method('PUT')


                {{-- JUDUL --}}
                <div>

                    <label
                        for="edit_judul_galeri"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Judul Gambar / Kegiatan

                    </label>

                    <input
                        type="text"
                        name="judul_galeri"
                        id="edit_judul_galeri"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                {{-- KATEGORI --}}
                <div>

                    <label
                        for="edit_kategori"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Kategori

                    </label>

                    <select
                        name="kategori"
                        id="edit_kategori"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                        <option value="">
                            -- Pilih Kategori --
                        </option>

                        <option value="Tari Tradisi">
                            Tari Tradisi
                        </option>

                        <option value="Modern Dance">
                            Modern Dance
                        </option>

                        <option value="Vokal">
                            Vokal
                        </option>

                        <option value="Kabaret">
                            Kabaret
                        </option>

                        <option value="Angklung & Musik">
                            Angklung & Musik
                        </option>

                        <option value="Foto Bersama">
                            Foto Bersama
                        </option>

                    </select>

                </div>


                {{-- TANGGAL --}}
                <div>

                    <label
                        for="edit_tanggal_upload"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Tanggal Upload

                    </label>

                    <input
                        type="date"
                        name="tanggal_upload"
                        id="edit_tanggal_upload"
                        required
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               focus:outline-none
                               focus:ring-2
                               focus:ring-[#4A0000]">

                </div>


                {{-- FOTO BARU --}}
                <div>

                    <label
                        for="edit_foto"
                        class="block
                               text-xs
                               font-bold
                               text-[#4A0000]
                               mb-1">

                        Ganti Foto

                    </label>

                    <input
                        type="file"
                        name="foto"
                        id="edit_foto"
                        accept="image/jpeg,image/png,image/jpg,image/webp"
                        class="w-full
                               px-3 py-2
                               rounded-lg
                               border border-gray-400
                               text-sm
                               bg-white">

                    <p
                        class="text-[11px]
                               text-gray-500
                               mt-1">

                        Kosongkan jika tidak ingin mengganti foto.

                    </p>

                </div>


                {{-- BUTTON --}}
                <div
                    class="flex justify-end
                           gap-2
                           pt-3">

                    <button
                        type="button"
                        onclick="closeEditModal()"
                        class="px-4 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-gray-200
                               text-gray-700
                               hover:bg-gray-300
                               transition">

                        Batal

                    </button>

                    <button
                        type="submit"
                        class="px-5 py-2
                               rounded-lg
                               text-xs
                               font-bold
                               bg-[#4A0000]
                               text-white
                               hover:bg-[#660000]
                               transition">

                        Simpan Perubahan

                    </button>

                </div>

            </form>

        </div>

    </div>


    {{-- =========================================================
         JAVASCRIPT
    ========================================================== --}}
    <script>

        /* =====================================================
           SIDEBAR
        ====================================================== */

        const menuToggle =
            document.getElementById('menuToggle');

        const sidebar =
            document.getElementById('sidebar');

        const sidebarOverlay =
            document.getElementById('sidebarOverlay');


        if (menuToggle && sidebar && sidebarOverlay) {

            menuToggle.addEventListener('click', function () {

                sidebar.classList.toggle('-translate-x-full');

                sidebarOverlay.classList.toggle('hidden');

            });


            sidebarOverlay.addEventListener('click', function () {

                sidebar.classList.add('-translate-x-full');

                sidebarOverlay.classList.add('hidden');

            });

        }


        /* =====================================================
           MODAL TAMBAH GALERI
        ====================================================== */

        const addModal =
            document.getElementById('addModal');


        function openAddModal() {

            addModal.classList.remove('hidden');

            addModal.classList.add('flex');

        }


        function closeAddModal() {

            addModal.classList.add('hidden');

            addModal.classList.remove('flex');

        }


        /* =====================================================
           MODAL EDIT GALERI
        ====================================================== */

        const editModal =
            document.getElementById('editModal');

        const editForm =
            document.getElementById('editForm');

        const editJudul =
            document.getElementById('edit_judul_galeri');

        const editKategori =
            document.getElementById('edit_kategori');

        const editTanggal =
            document.getElementById('edit_tanggal_upload');


        function openEditModal(
            id,
            judul,
            kategori,
            tanggal
        ) {

            // Masukkan data lama
            editJudul.value = judul;

            editKategori.value = kategori;

            editTanggal.value = tanggal;


            // URL update
            editForm.action =
                "{{ url('/admin/galeri') }}/" + id;


            // Tampilkan modal
            editModal.classList.remove('hidden');

            editModal.classList.add('flex');

        }


        function closeEditModal() {

            editModal.classList.add('hidden');

            editModal.classList.remove('flex');

        }


        /* =====================================================
           KLIK LUAR MODAL TAMBAH
        ====================================================== */

        addModal.addEventListener('click', function (event) {

            if (event.target === addModal) {

                closeAddModal();

            }

        });


        /* =====================================================
           KLIK LUAR MODAL EDIT
        ====================================================== */

        editModal.addEventListener('click', function (event) {

            if (event.target === editModal) {

                closeEditModal();

            }

        });


        /* =====================================================
           TOMBOL ESC
        ====================================================== */

        document.addEventListener('keydown', function (event) {

            if (event.key === 'Escape') {

                closeAddModal();

                closeEditModal();

            }

        });

    </script>

</body>
</html>